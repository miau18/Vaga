import java.util.Scanner;

public class Ex3 {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		int indice=12;
		int soma=0;
		int k=1;
		
		while(k<indice) {
			k=k+1;
			soma=soma+k;
		}
		System.out.println(soma);
	}

}
