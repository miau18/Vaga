import java.util.Scanner;

public class Ex2 {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		String frase;
		int quantidadeDeA=0;
		
		System.out.println("Escreva uma palavra ou frase");
		frase=scanner.nextLine();
		
		for(int i=0; i<frase.length(); i++) {
			char a = frase.charAt(i);
			if(a=='a' || a=='A') {
				quantidadeDeA++;
			}
			
		}
		
		if(quantidadeDeA > 0) {
			System.out.println("A letra a aparece "+quantidadeDeA+" vezes");
		}else {
			System.out.println("A letra a não aparece");
		}
		
		scanner.close();
	}

}
