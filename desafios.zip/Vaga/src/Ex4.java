import java.util.Scanner;

public class Ex4 {
	
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner (System.in);
		
		//sequência a = número + 2
		int a=7;
		int somaA;
		somaA=a+2;
		System.out.println("O próximo número da sequência A) "+somaA);
		
		//sequência b = número + ele mesmo(ou *2)
		int b=64;
		int somaB;
		somaB=b+b;
		System.out.println("O próximo número da sequência B) "+somaB);
		
		//sequência c = número elevado ao quadrado
		int c=7;
		int somaC;
		somaC=c*c;
		System.out.println("O próximo número da sequência C) "+somaC);
		
		//sequência d= número par elevado ao quadrado
		int d=10;
		int somaD;
		somaD=d*d;
		System.out.println("O próximo número da sequência D) "+somaD);
		
		//sequência e= sequência d Fibonacci
		int e=5;
		int e2=8;
		int somaE=e+e2;
		System.out.println("O próximo número da sequência E) "+somaE);
		
		//sequência f= numeros pares alternaod, após o 10, sequência crescente de impares
		int f=20;
		System.out.println("O próximo número da sequência F) "+f);
	}

}
