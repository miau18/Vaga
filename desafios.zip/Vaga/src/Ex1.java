import java.util.Scanner;

public class Ex1 {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		int numero;
		
		//números para a sequência de Fiboncci
		int primeiroNumero=0;
		int segundoNumero=1;
		
		System.out.println("Informe um número");
		numero = scanner.nextInt();
		
		
		if(numero==primeiroNumero || numero==segundoNumero) {
			System.out.println("O número "+numero+" pertence a sequência de Fibonacci");
		}else {
			int proximo=primeiroNumero+segundoNumero;
			while(proximo <= numero) {
				if(proximo==numero) {
				System.out.println("O número "+numero+" pertence a sequência de Fibonacci");
				return;
			}
			
			primeiroNumero = segundoNumero;
			segundoNumero = proximo;
			proximo = primeiroNumero + segundoNumero;
		}
		
		
		System.out.println("O número "+numero+" não pertence a sequência de Fibonacci");
		
		
	}
 scanner.close();
}
}
